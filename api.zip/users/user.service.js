
const pool = require('../config/database');



module.exports = {
    create: (data, callback)=>
    pool.query(
        `insert into registration (firstname,lastname) values (?,?)`,
        [
            data.firstname,
            data.lastname
        ],

        (error, results, fields)=>{
                if(error){
                    return callback(error);
                }
                return callback(null, results)
        }
    )
}
